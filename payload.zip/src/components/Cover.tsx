'use client';

import React, { useState, useEffect } from 'react';
import type { ProposalMeta, SiteSettings } from '@/lib/schema/types';
import { normalizeImageUrl } from '@/lib/schema/types';
import Footer from './Footer';

interface CoverProps {
  meta: ProposalMeta;
  settings: SiteSettings;
}

export default function Cover({ meta, settings }: CoverProps) {
  const coverUrl = normalizeImageUrl(meta.cover_image_url);
  const [currentSrc, setCurrentSrc] = useState(coverUrl);
  const [imgError, setImgError] = useState(false);
  const [hasTriedProxy, setHasTriedProxy] = useState(false);

  useEffect(() => {
    setCurrentSrc(coverUrl);
    setImgError(false);
    setHasTriedProxy(false);
  }, [coverUrl]);

  const handleImgError = () => {
    if (currentSrc && currentSrc.includes('lh3.googleusercontent.com/d/')) {
      const id = currentSrc.split('lh3.googleusercontent.com/d/')[1];
      if (id) {
        setCurrentSrc(`https://drive.google.com/uc?export=view&id=${id}`);
        return;
      }
    }
    // Fallback to image-proxy if direct loading fails
    if (coverUrl && !hasTriedProxy && (coverUrl.startsWith('http://') || coverUrl.startsWith('https://'))) {
      setHasTriedProxy(true);
      setCurrentSrc(`/api/image-proxy?url=${encodeURIComponent(coverUrl)}`);
      return;
    }
    setImgError(true);
  };

  // Title split for aesthetic line breaking matching design
  const formattedTitle = (meta.title || '').replace(/\b(TOUR)\b/i, '<br>$1');

  return (
    <section className="proposal-page cover-page relative w-[210mm] h-[297mm] mx-auto mb-6 bg-white overflow-hidden print:m-0 print:break-after-page shadow-md print:shadow-none">
      {/* Rounded Hero Image Container */}
      <div className="absolute left-[10mm] top-[9mm] right-[10mm] h-[196mm] rounded-[12mm] overflow-hidden bg-gradient-to-b from-[#8a94ad] via-[#f0a35a] to-[#7d8f88]">
        {currentSrc && !imgError ? (
          <img
            className="w-full h-full object-cover"
            src={currentSrc}
            alt={meta.title}
            loading="eager"
            referrerPolicy="no-referrer"
            onError={handleImgError}
          />
        ) : null}
      </div>

      {/* Notch holding Logo */}
      <div className="absolute left-[10mm] top-[9mm] w-[90mm] h-[46mm] bg-white rounded-br-[12mm] flex items-center justify-center p-[3mm]">
        <img
          className="max-w-[75mm] max-h-[36mm] object-contain"
          src={settings.logo_url || '/logo.png'}
          alt={settings.company_name}
          loading="eager"
          referrerPolicy="no-referrer"
        />
      </div>

      {/* Title */}
      <h1
        className="absolute left-[12mm] right-[10mm] top-[217mm] text-[21mm] leading-[.98] font-medium tracking-tight text-black"
        dangerouslySetInnerHTML={{ __html: formattedTitle }}
      />

      {/* Footer */}
      <Footer settings={settings} />
    </section>
  );
}
